package com.example.springbootfirst.controllers;

public class Hello {
    public String helloTest(){
        return "Hello Test";
    }
}
